import Toybox.Lang;
import Toybox.Graphics;
import Toybox.System;
import Toybox.Test;

// Fitness is compiled from the production body with only Garmin module
// references mapped to the counting API fake in MetricBoundary.mc.
(:test,:typecheck(false)) function display03MetricRolesAndAge(logger){
 var f=new BoundaryFitness();f.selectedRoles=["energy","energy","battery","calories"];
 MetricSDK.reset(0);var atLimit=f.sample(1800000300);
 Test.assert(atLimit["energy"]==68&&atLimit["battery"]==82&&atLimit["calories"]==2345);
 Test.assert(atLimit["heart"]==null&&atLimit["stress"]==null);
 Test.assert(traceEquals(["activity.info","system.stats","energy.open","energy.next"]));
 MetricSDK.reset(0);var aged=f.sample(1800000301);Test.assert(aged["energy"]==null);
 MetricSDK.reset(3);var absent=f.sample(1800000000);Test.assert(absent["energy"]==null);
 MetricSDK.reset(1);var denied=f.sample(1800000000);Test.assert(denied["energy"]==null);
 MetricSDK.reset(0);var fresh=f.sample(1800000000);Test.assert(fresh["energy"]==68);
 f.selectedRoles=["heart","heart","heart","heart"];MetricSDK.reset(0);f.sample(1800000000);
 Test.assert(traceEquals(["heart.open","heart.next"]));
 f.selectedRoles=[];MetricSDK.reset(0);f.sample(1800000000);Test.assert(traceEquals([]));
 Test.assert(f.recentValue(0,1800000000,1800000000,100,false)==0);
 logger.debug("METRIC_ROLE duplicate=one age300=accepted age301=unavailable absent=unavailable denied=unavailable fresh=restored");return true;
}
(:test,:typecheck(false)) class D03CountFitness extends Fitness {
 var calls=0;function initialize(){Fitness.initialize();}
 function sample(now){calls+=1;return {"steps"=>null,"calories"=>null,"battery"=>null,"heart"=>null,"energy"=>null,"stress"=>null};}
}
(:test,:typecheck(false)) function display03LowDoesNotSample(logger){
 var v=new SpaceFoxView(new Display03Clock(),new ScheduleState(null,"empty"));var f=new D03CountFitness();v.fitness=f;
 v.onEnterSleep();v.refreshFitness();Test.assert(f.calls==0);v.onHide();return true;
}
(:test,:typecheck(false)) function display03OffStopsWork(logger){
 var v=new SpaceFoxView(new Display03Clock(),new ScheduleState(null,"empty"));var f=new D03CountFitness();v.fitness=f;
 var d=new Display03ModeRenderer();v.renderer=d;v.onShow();Test.assert(v.sceneLifecycle.request(1));
 var dc=Graphics.createBufferedBitmap({:width=>390,:height=>390}).get().getDc();var loads=d.resourceLoads;
 v.updateForDisplayMode(dc,System.DISPLAY_MODE_OFF);Test.assert(d.activeCalls==0&&d.lowCalls==0&&f.calls==0&&d.resourceLoads==loads&&!v.sceneLifecycle.pending());
 var generation=v.sceneLifecycle.generation;v.updateForDisplayMode(dc,System.DISPLAY_MODE_OFF);Test.assert(v.sceneLifecycle.generation==generation&&d.resourceLoads==loads);
 v.updateForDisplayMode(dc,System.DISPLAY_MODE_HIGH_POWER);Test.assert(d.activeCalls==1&&f.calls==0);v.onHide();
 logger.debug("OFF noPaintOrSampling=true cancelOnce=true highFirstFrameBeforeSampling=true");return true;
}
